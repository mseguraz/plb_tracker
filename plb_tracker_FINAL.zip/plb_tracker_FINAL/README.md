# GNR_tracking_plbs
Scripts to generate table with plbs and content in kill for compute GNR

### How to run:

1. Clone or download repository.

2. Install `requirements.txt`. Further instructions for linux below.

```bash
pip install -r requirements.txt
```

3. Run  script. Either use a TP from its original location:

```bash
python main.py --tp tp_folder_path --table name_of_excel --plist plist_path(optional)  --config_file config.py(optional) --patmod path_of_patmod(optional) --f class/sort --chop name_of_chop(ucc/xcc/hcc/lcc) --op cold/hot  --format txt/excel -separate (optional) -iodie (optional) -fused (optional)
```
 
 Or a config file:

 ```bash
 python main.py --config_file config.py --table name_of_excel --plist plist_path(optional) --f class/sort --chop name_of_choname_of_chop(ucc/xcc/hcc/lcc)p --op cold/hot --patmod path_of_patmod(optional) --format txt/excel -separate (optional) -iodie (optional) -fused (optional)
 ```

 4. Table will be generated as `name_of_excel.xlsx`. An aditional audit table will be generated as either `name_of_excel_audit.xlsx` or `name_of_excel.txt`.

 ### Priorities
 Multiple instances of the same scan region can be running in kill. In that case, table will report content with these priorities:

 1. Most recent rev.
 2. If they have the same rev, the one with most chunks.
 3. If they have same rev and number of chunks, the one that is not in EDC.

 ### Config file
When you generate the table from a TP folder, by default, the following flows will be included in the table:

SORT:
* SCN_UNCORE_COMP_BEGIN
* ATPG (from END)
* TATPG (from END)
* SCN_UNCORE_COMP_EXVF
* SDT_ATPG
* SDT_TATPG
* SCN_UNCOREHVQK_COMP_PREHVQK
* SCN_UNCOREHVQK_COMP_POSTHVQK
* SCN_UNCOREHVQK_COMP_VMAX

SORT IODIE:
* SCN_UNCORE_IO_BEGIN
* ATPG_END
* TATPG_END
* SCN_UNCORE_IO_EXVF
* SDTEND_ATPG_MP
* SDTEND_TATPG_MP
* SCN_UNCOREHVQK_IO_PREHVQK
* SCN_UNCOREHVQK_IO_POSTHVQK
* SCN_UNCOREHVQK_IO_STRESS

CLASS IODIE
* atpg_io_hvm_begin
* SCN_UNCORE_IO_SRH_CFCIO_F1
* SCN_UNCORE_IO_CHK_CFCIO_F1
* SCN_UNCORE_IO_SRH_CFCIO_F2
* SCN_UNCORE_IO_CHK_CFCIO_F2
* SCN_UNCORE_IO_SRH_CFN_F3
* SCN_UNCORE_IO_SRH_CFN_F4
* SCN_UNCORE_IO_CHK_CFN_F4
* SCN_UNCORE_IO_VMAX_CFCIO
* SCN_UNCORE_IO_SRH_CFN_F1
* SCN_UNCORE_IO_CHK_CFN_F1
* SCN_UNCORE_IO_VMAX_CFNHCA
* SCN_UNCORE_IO_VMAX_CFNPCIE
* SCN_UNCORE_IO_VMAX_CFNUPI
* SCN_UNCORE_IO_SRH_VCCINF
* SCN_UNCORE_IO_CHK_VCCINF
* SCN_UNCORE_IO_VMAX_VINF
* SCN_UNCORE_IO_END
* LTTC
* I2TD
* MDI
* ALLTEST

CLASS:
* atpg_comp_hvm_begin
* tatpg_comp_hvm_begin
* SCN_SCAN_COMP_SRH_VCCINF
* SCN_SCAN_COMP_CHK_VCCINF
* SCN_SCAN_COMP_VMAX_VINF
* SCN_SCAN_COMP_SRH_CFCHDC_F1
* SCN_SCAN_COMP_CHK_CFCHDC_F1
* SCN_SCAN_COMP_SRH_CFCHDC_F2
* SCN_SCAN_COMP_CHK_CFCHDC_F2
* SCN_SCAN_COMP_SRH_CFCHDC_F3
* SCN_SCAN_COMP_SRH_CFCHDC_F4
* SCN_SCAN_COMP_CHK_CFCHDC_F4
* SCN_SCAN_COMP_VMAX_CFCCOMP
* SCN_SCAN_COMP_SRH_DDRD_F1
* SCN_SCAN_COMP_CHK_DDRD_F1
* SCN_SCAN_COMP_SRH_DDRD_F2
* SCN_SCAN_COMP_CHK_DDRD_F2
* SCN_SCAN_COMP_SRH_DDRD_F3
* SCN_SCAN_COMP_CHK_DDRD_F3
* SCN_SCAN_COMP_VMAX_DDRD
* EXTEST
* ATPG
* LTTC
* I2TD

You can specify which flows do you want to include in `config.py` as following:
```python
# this flows are defined in uncore mtpl file
FLOWS_UNCORE={'begin': ['SCN_UNCORE_COMP_BEGIN'], 
              'end atpg': ['ATPG'], 
              'end tatpg': ['TATPG'],
              'end edc': ['UNCORE_END_EDC'],
              'exvf': ['SCN_UNCORE_COMP_EXVF'],
              'sdt atpg' : ['SDT_ATPG'],
              'sdt tatpg' : ['SDT_TATPG']}

#this flows have to be defined in hvkq mtpl file
FLOWS_HVQK={'prehvqk': ['SCN_UNCOREHVQK_COMP_PREHVQK'], 
            'vmax': ['SCN_UNCOREHVQK_COMP_VMAX']}

#this flows have to be defined in class mtpl file
FLOWS_CLASS={'begin_atpg': ['atpg_comp_hvm_begin'], 
            'end_atpg': ['ATPG']}
```

You can run the config file alongside the `tp` flag:

```bash
python main.py --tp tp_folder_path --config config.py --table name_of_excel --plist plist_path(optional)  --config_file config.py(optional) --patmod path_of_patmod(optional) --f class/sort --chop name_of_chop(ucc/xcc/hcc/lcc) --op cold/hot  --format txt/excel -separate(optional) -iodie (optional) -fused (optional)
```

In this case, the table will be generated only for the flows defined in the config file. Alternatively, you can define specific mtpl files and the flows for each mtpl file you want to include in the table:

 ```python
 # Mtpl path for each flow
mtpls=["mtpl_path_flows1", 
       "mtpl_path_flows2",
       "mtpl_path_flows3", 
       'etc',
       ]

#flows for each mtpl file
# name: name of DUTFlow as it appears in mtpl file
flows1={'begin': 'SCN_UNCORE_COMP_BEGIN',
        'end': 'ATPG',
        'etc'
        }

flows2={'prehvqk': 'SCN_UNCOREHVQK_COMP_PREHVQK', 
        }

flows3=...

#add all your flows into this list
flows=[flows1, flows2, flows3, etc]

#OPTIONAL: path of plist to use. Overwrittes --plist flag when running script if not set to None
plist=r'\\samba.zsc11.intel.com\nfs\site\disks\mfg_cwf_001\nmzuniga\scan_uncore_base_sort_cwb.plist'
#plist = None # uncomment this if using --plist flag

#DO NOT TOUCH THIS. KEEP IT AS IT IS.
names = [key for flow in flows for key in flow.keys()]
 ```

This last configuration will only be used if `tp` flag is not defined when executing main.

### Output

Script will always generate a table like the following:

![My Image](packages/table.png)

An audit table detailing running instances, bin, plist, and plb tracking will be generated in either txt or excel with `--format` flag:

| txt | excel |
|---------|---------|
| ![Image 1](packages/txt.png) | ![Image 2](packages/excel.png) |

You can indicate if the tracking should explicitly tell is a content is ATPG or TATPG with `-separate` flag:

| No separate | Separate |
|---------|---------|
| ![Image 1](packages/atpg.png) | ![Image 2](packages/tatpg.png) |

 ### Flags for class only:

`chop` is the name of chop. Valid options are XCC, UCC, HCC and LCC.

`op` is the operation. Valid ops are HOT and COLD.

`chop`, `op` flags are mandatory when `f` (flow) is class. 

Examples:

```bash
python main.py --config_file config.py --table name_of_excel --plist plist_path(optional) --f class --chop xcc --op cold --patmod path_of_patmod(optional) --format excel -separate
 ```

For sort: 

```bash
python main.py --tp tp_folder_path  --config_file config.py --table name_of_excel --plist plist_path(optional) --f sort --patmod path_of_patmod(optional) --format txt
```

 ### IODIE:

 `iodie` generates table for IODIE content instead of COMPUTE.

 `fused` indicates that unit is fused.

 If running script for IODIE SORT, a prompt will indicate user to select either DSTEP or ESTEP for generating table.

 ## Very important
 Make sure each flow is explicitly defined as a DUTFlow in mtpl file. Otherwhise program will fail

 In windows, use full name of mapped hard drive. For example use path \\\\samba.zsc11.intel.com\nfs\site\disks\user instead of Z:\user to prevent path issues.

 Make sure you run the script in same location where `main.py` is.

 ## Running script on linux

You can run the script in a linux environment for CLASS TPs (SORT only works when run from VS). Some sites use an older version of python, but have more recent compilers. To set up a linux environment, follow these steps:

1. See where the python interpreter is (usually it's in /usr/intel/bin/):
```bash
which python
```
2. Look-up which python interpreters there are (for example, previous command returned /usr/intel/bin/python):
```bash
ls /usr/intel/bin/python*
```
3. Select an available interpreter over 3.8 to generate a virtual environment (for example, python 3.10.8):
```bash
python3.10.8 -m venv env
```
4. Activate the environment (for tcsh terminal, usually is with this command):
```bash
source env/bin/activate.csh
```
5. Now you can install the requirements and run the script normally. 