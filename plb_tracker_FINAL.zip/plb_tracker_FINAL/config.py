#OPTION 1: 
'''
#Uncomment this for using these flows. They will be used alongise the TP you defined

#these flows are defined in uncore mtpl file
FLOWS_UNCORE={'begin': ['SCN_UNCORE_COMP_BEGIN'], 
              'end atpg' : ['ATPG']
              }

#these flows have to be defined in hvkq mtpl file
FLOWS_HVQK={'prehvqk': ['SCN_UNCOREHVQK_COMP_PREHVQK'], 
            #'posthvqk': ['SCN_UNCOREHVQK_COMP_POSTHVQK'],
            'stress': ['SCN_UNCOREHVQK_COMP_HOTSTRESS'],
            }
#these flows have to be defined in class mtpl file         
FLOWS_CLASS={'vmax': ['VMAX_CFCCOMP'], 
             }
			 
#these flows are defined in iodie sort mtpl file
FLOWS_IODIE={
    'end atpg': ['ATPG_END'], 
    'end tatpg': ['TATPG_END'],
    'exvf': ['SCN_UNCORE_IO_EXVF'],
}

#these flows have to be defined in hvkq mtpl file for iodie
FLOWS_IODIE_HVQK={'prehvqk': ['SCN_UNCOREHVQK_IO_PREHVQK'],                                         
                  }
				  
#these flows have to be defined in class mtpl file for IODIE  
FLOWS_IODIE_CLASS={
    'lttc': ['LTTC'],
    'end': ['SCN_UNCORE_IO_END'],
    'alltest': ['ALLTEST'],
}
             
'''
#OPTION 2

#Uncomment this for using these variables. 

#List with mtpl paths you want to use
mtpls=[r"I:\\intel\\engineering\\dev\\dcd\\scan\\agloriaj\\25ww06p2_Release\\Modules\\SCN_SCAN_COMP\SCN_SCAN_COMP.mtpl", 
       ]

#IMPORTANT: use full path if using mapped hard drive
#For example, do NOT use "U:\program", use instead:
# r"\\s46file1.cd.intel.com\program"

#flows for each mtpl file
flows1={
        'vmax_cfccomp': 'SCN_SCAN_COMP_VMAX_CFCCOMP',
        'srh_ddrd_f1': 'SCN_SCAN_COMP_SRH_DDRD_F1',
        'chk_ddrd_f1': 'SCN_SCAN_COMP_CHK_DDRD_F1',
        'srh_ddrd_f2': 'SCN_SCAN_COMP_SRH_DDRD_F2',
        'chk_ddrd_f2': 'SCN_SCAN_COMP_CHK_DDRD_F2',
        'srh_ddrd_f3': 'SCN_SCAN_COMP_SRH_DDRD_F3',
        'chk_ddrd_f3': 'SCN_SCAN_COMP_CHK_DDRD_F3',
        'vmax_ddrd': 'SCN_SCAN_COMP_VMAX_DDRD',
        'end_extest': 'EXTEST',
        'end_atpg': 'ATPG',
        'lttc': 'LTTC',
        'i2td': 'I2TD',}

flows2={'prehvqk': 'SCN_UNCOREHVQK_COMP_PREHVQK', 
        'vmax': 'SCN_UNCOREHVQK_COMP_VMAX',
        }

#add all your flows into this list
flows=[flows1, ]

#OPTIONAL: path of plist to use. Overwrittes --plist flag when running script if not set to None
plist=None
#plist = None # uncommwnt this if using --plist flag

#DO NOT TOUCH THIS
names = [key for flow in flows for key in flow.keys()]
# name: name of DUTFlow as it appears in mtpl file

